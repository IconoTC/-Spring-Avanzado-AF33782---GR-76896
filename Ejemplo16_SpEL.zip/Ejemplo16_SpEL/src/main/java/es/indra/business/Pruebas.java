package es.indra.business;

import java.util.List;

import es.indra.models.Cliente;

public class Pruebas {

	private int valorContador;
	private double importeCompras;
	private List<Cliente> clientes;
	private List<Cliente> mejoresClientes;
	private List<String> datos;

	public int getValorContador() {
		return valorContador;
	}

	public void setValorContador(int valorContador) {
		this.valorContador = valorContador;
	}

	public double getImporteCompras() {
		return importeCompras;
	}

	public void setImporteCompras(double importeCompras) {
		this.importeCompras = importeCompras;
	}

	public List<Cliente> getClientes() {
		return clientes;
	}

	public void setClientes(List<Cliente> clientes) {
		this.clientes = clientes;
	}

	public List<Cliente> getMejoresClientes() {
		return mejoresClientes;
	}

	public void setMejoresClientes(List<Cliente> mejoresClientes) {
		this.mejoresClientes = mejoresClientes;
	}

	public List<String> getDatos() {
		return datos;
	}

	public void setDatos(List<String> datos) {
		this.datos = datos;
	}

}
