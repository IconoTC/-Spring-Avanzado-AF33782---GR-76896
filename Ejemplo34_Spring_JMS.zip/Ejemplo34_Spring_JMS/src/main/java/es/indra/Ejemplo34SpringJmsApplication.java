package es.indra;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import es.indra.business.MessageProductor;

@SpringBootApplication
public class Ejemplo34SpringJmsApplication implements CommandLineRunner{
	
	@Autowired
	private MessageProductor productor;

	public static void main(String[] args) {
		SpringApplication.run(Ejemplo34SpringJmsApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		productor.enviarMensaje("myQueue", "Esto es una prueba de JMS");		
	}

}
