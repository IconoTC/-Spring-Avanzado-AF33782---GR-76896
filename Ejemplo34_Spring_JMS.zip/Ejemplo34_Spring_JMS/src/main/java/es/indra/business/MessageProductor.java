package es.indra.business;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.stereotype.Service;

@Service
public class MessageProductor {
	
	@Autowired
	private JmsTemplate jmsTemplate;
	
	public void enviarMensaje(String cola, String mensaje) {
		jmsTemplate.convertAndSend(cola, mensaje);
		System.out.println("******* Mensaje enviado *******");
	}

}
