package es.indra.business;

import org.springframework.jms.annotation.JmsListener;
import org.springframework.stereotype.Service;

@Service
public class MessageConsumidor {
	
	@JmsListener(destination = "myQueue")
	public void recibirMensaje(String mensaje) {
		System.out.println("Mensaje recibido: " + mensaje);
	}

}
