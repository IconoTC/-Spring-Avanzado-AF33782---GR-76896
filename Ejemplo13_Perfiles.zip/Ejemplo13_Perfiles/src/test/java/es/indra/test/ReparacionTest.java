package es.indra.test;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import es.indra.business.Aseguradora;
import es.indra.models.Coche;

@RunWith(value = SpringJUnit4ClassRunner.class)
@ContextConfiguration(name = "classpath:applicationContext.xml")
@ActiveProfiles("mecanica")
public class ReparacionTest {

	@Test
	public void prueba() {

//		ApplicationContext contenedor = new ClassPathXmlApplicationContext("applicationContext.xml");
//
//		// Recuperar el bean coche del contenedor
//		Coche coche = (Coche) contenedor.getBean("coche");
//
//		// Recuperar el bean aseguradora del contenedor
//		Aseguradora aseguradora = contenedor.getBean("aseguradora", Aseguradora.class);
//
//		aseguradora.arreglarCoche(coche);

	}

}
