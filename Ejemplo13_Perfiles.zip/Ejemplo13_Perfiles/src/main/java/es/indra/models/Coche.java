package es.indra.models;

public class Coche {
	
	private String matricula;
	private String modelo;
	
	// Spring necesita tener un constructor sin argumentos
	public Coche() {
		// TODO Auto-generated constructor stub
	}

	public Coche(String matricula, String modelo) {
		super();
		this.matricula = matricula;
		this.modelo = modelo;
	}

	// Spring necesita los metodos get y set de todas las propiedades
	public String getMatricula() {
		return matricula;
	}

	public void setMatricula(String matricula) {
		this.matricula = matricula;
	}

	public String getModelo() {
		return modelo;
	}

	public void setModelo(String modelo) {
		this.modelo = modelo;
	}

	@Override
	public String toString() {
		return "Coche [matricula=" + matricula + ", modelo=" + modelo + "]";
	}

}
