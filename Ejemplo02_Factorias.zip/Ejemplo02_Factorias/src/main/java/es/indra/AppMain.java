package es.indra;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import es.indra.business.Contabilidad;

public class AppMain {

	public static void main(String[] args) {
		// Levantamos el contexto de spring (crear el contenedor con los beans)
		ApplicationContext contenedor = new ClassPathXmlApplicationContext("applicationContext.xml");
		
		// Recuperar el bean contabilidad
		Contabilidad contabilidad = contenedor.getBean("contabilidad", Contabilidad.class);
		
		contabilidad.movimiento("Pago alquiler");
		contabilidad.movimiento("Amortizacion de maquinaria");
		
		// Recuperar el libro contable
		Contabilidad libro = contenedor.getBean("libro", Contabilidad.class);
		libro.movimiento("Pago de nominas");
		libro.movimiento("Compra de material");

	}

}
