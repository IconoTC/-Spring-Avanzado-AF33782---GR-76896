package es.indra.business;

public class ServicioContabilidad {
	
	public Contabilidad getLibroContable() {
		return Contabilidad.getInstance();
	}

}
