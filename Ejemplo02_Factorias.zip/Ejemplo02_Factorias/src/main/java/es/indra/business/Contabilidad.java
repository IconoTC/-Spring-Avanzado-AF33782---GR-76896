package es.indra.business;

public class Contabilidad {
	
	// Propiedad estatica que almacena la unica instancia de la clase
	private static Contabilidad instance = new Contabilidad();
	
	// Constructor es privado para evitar la creacion de otros objetos
	private Contabilidad() {
		// TODO Auto-generated constructor stub
	}
	
	// Metodo estatico que retorna la unica instancia
	public static Contabilidad getInstance() {
		return instance;
	}
	
	// Metodos de negocio
	public void movimiento(String datos) {
		System.out.println("Anotando en el libro de contabilidad " + datos);
	}

}
