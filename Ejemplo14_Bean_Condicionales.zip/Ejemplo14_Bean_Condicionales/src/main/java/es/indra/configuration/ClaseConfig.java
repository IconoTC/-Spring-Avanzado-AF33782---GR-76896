package es.indra.configuration;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Conditional;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;

import es.indra.negocio.ClientesBS;
import es.indra.persistencia.ClientesDAO;
import es.indra.persistencia.ClientesDAOTest;
import es.indra.persistencia.ItfzDAO;


@Configuration
//@ComponentScan(basePackages="es.indra")
public class ClaseConfig {
	
	@Bean
	@Primary
	@Conditional(MyCondition.class)
	public ItfzDAO clientesDAO(){
		return new ClientesDAO();
	}
	
	@Bean
	public ItfzDAO clientesDAOTest(){
		return new ClientesDAOTest();
	}
	
	@Bean
	public ClientesBS clientesBS(){
		ClientesBS clientesBS = new ClientesBS();
		//clientesBS.setDao(clientesDAOTest());
		return clientesBS;
	}
	
}

