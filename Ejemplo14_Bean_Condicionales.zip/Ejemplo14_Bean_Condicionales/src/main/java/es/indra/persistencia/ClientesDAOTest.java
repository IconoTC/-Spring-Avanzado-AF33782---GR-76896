package es.indra.persistencia;

import org.springframework.stereotype.Repository;

//@Repository
public class ClientesDAOTest implements ItfzDAO{
	
	@Override
	public void insertar(Object object) {
		// TODO Auto-generated method stub
		System.out.println("Insertando objeto en la BBDD de prueba");
	}

}
