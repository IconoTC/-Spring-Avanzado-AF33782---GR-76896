package es.indra.cliente;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import es.indra.negocio.ClientesBS;

public class AppMain {

	public static void main(String[] args) {
		// Levantar el contexto de Spring
		// Crear el contenedor de beans a partir de la clase de configuración ClaseConfig
		ApplicationContext context = new AnnotationConfigApplicationContext(es.indra.configuration.ClaseConfig.class);
		
		// Recuperar del contenedor el bean de negocio
		// ClientesBS clientesBS = (ClientesBS) context.getBean("clientesBS");
		ClientesBS clientesBS = context.getBean("clientesBS", ClientesBS.class);
		
		// Ejecutar
		clientesBS.altaCliente("Datos del cliente");
	}

}
