package es.indra.negocio;

import org.springframework.beans.factory.annotation.Autowired;

import es.indra.persistencia.ItfzDAO;

public class ClientesBS {

	@Autowired
	private ItfzDAO dao;

	// Metodo que Spring necesita para que se inyecte la propiedad dao
	public void setDao(ItfzDAO dao) {
		this.dao = dao;
	}

	// Spring necesita de un constructor sin argumentos
	public ClientesBS() {
		// TODO Auto-generated constructor stub
	}

	public void altaCliente(Object cliente) {
		dao.insertar(cliente);
	}

}
