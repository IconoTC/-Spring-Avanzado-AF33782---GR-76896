package es.indra.models;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Lazy;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

// El id del bean sera el nombre de la clase con la primera letra en minuscula
@Component("coche")
@Scope("singleton")
@Lazy   // El bean se genera bajo demanda
public class Coche {
	
	// @Value se utiliza solo para tipos primitivos y String
	@Value("1234-LVF")
	private String matricula;
	
	@Value("A5")
	private String modelo;
	
	// Spring necesita tener un constructor sin argumentos
	public Coche() {
		// TODO Auto-generated constructor stub
	}

	public Coche(String matricula, String modelo) {
		super();
		this.matricula = matricula;
		this.modelo = modelo;
	}

	// Spring necesita los metodos get y set de todas las propiedades
	public String getMatricula() {
		return matricula;
	}

	public void setMatricula(String matricula) {
		this.matricula = matricula;
	}

	public String getModelo() {
		return modelo;
	}

	public void setModelo(String modelo) {
		this.modelo = modelo;
	}

	@Override
	public String toString() {
		return "Coche [matricula=" + matricula + ", modelo=" + modelo + "]";
	}

}
