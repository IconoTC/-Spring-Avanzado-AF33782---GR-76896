package es.indra.business;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import es.indra.models.Coche;

@Service
public class Aseguradora {
	
	@Value("Mapfre")
	private String nombre;
	
	// Con @Autowired no me permite poner el identificador del bean
	@Autowired
	@Qualifier("tallerPintura")
	//@Resource(name = "tallerPintura")
	private ITaller taller;  // Inyeccion de dependencias
	
	public void arreglarCoche(Coche coche) {
		taller.reparar(coche);
	}

	// Spring necesita los get y set para poder inyectar
	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public ITaller getTaller() {
		return taller;
	}

	public void setTaller(ITaller taller) {
		this.taller = taller;
	}
	
}
