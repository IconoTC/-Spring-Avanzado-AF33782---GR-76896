package es.indra.business;

import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Service;

import es.indra.models.Coche;

//El id del bean sera el nombre de la clase con la primera letra en minuscula
@Service
//@Primary   // Le doy preferencia para la inyeccion
public class TallerPintura implements ITaller{

	@Override
	public void reparar(Coche coche) {
		System.out.println("En el taller de pintura se repara el coche " + coche);
		
	}

}
