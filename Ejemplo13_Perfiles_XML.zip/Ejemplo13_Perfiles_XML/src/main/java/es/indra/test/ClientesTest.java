package es.indra.test;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import es.indra.negocio.ClientesBS;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(name="classpath:applicationContext.xml")
@ActiveProfiles("test")
public class ClientesTest {

	@Test
	public void prueba() {

		ApplicationContext context = new ClassPathXmlApplicationContext(
				"applicationContext.xml");

		ClientesBS clientesBS = context.getBean("clientesBS", ClientesBS.class);

		clientesBS.altaCliente("Datos del cliente");

	}

}
