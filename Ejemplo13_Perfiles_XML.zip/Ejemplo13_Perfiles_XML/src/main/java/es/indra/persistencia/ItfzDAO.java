package es.indra.persistencia;

public interface ItfzDAO {
	
	public void insertar(Object object);

}
