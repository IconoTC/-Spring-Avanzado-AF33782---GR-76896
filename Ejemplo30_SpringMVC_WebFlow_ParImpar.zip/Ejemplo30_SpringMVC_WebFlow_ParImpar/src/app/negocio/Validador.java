package app.negocio;

import org.springframework.stereotype.Component;

@Component
public class Validador {

		public boolean comprobar(int numero){
			if (numero % 2 == 0)
				return true;
			else
				return false;
		}
}
