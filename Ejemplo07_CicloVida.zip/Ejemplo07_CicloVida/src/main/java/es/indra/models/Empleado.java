package es.indra.models;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;

public class Empleado implements InitializingBean, DisposableBean{
	
	private int numeroEmpleado;
	private String nombre;
	private String apellido;
	private boolean jefe;
	private double sueldo;
	
	// Siempre es necesario mantener el constructor por defecto
	public Empleado() {
		// TODO Auto-generated constructor stub
	}

	public Empleado(int numeroEmpleado, String nombre, String apellido, boolean jefe, double sueldo) {
		super();
		this.numeroEmpleado = numeroEmpleado;
		this.nombre = nombre;
		this.apellido = apellido;
		this.jefe = jefe;
		this.sueldo = sueldo;
	}
	

	// Metodo de la interface DisposableBean
	@Override
	public void destroy() throws Exception {
		System.out.println("DisposableBean - Se va a destruir el bean");
	}

	// Metodo de la interface InitializingBean
	@Override
	public void afterPropertiesSet() throws Exception {
		System.out.println("Se acaban de inyectar las propiedades");	
	}
	
	@PreDestroy
	public void preDestroy() {
		System.out.println("@PreDestroy - Se va a destruir el bean");
	}
	
	@PostConstruct
	public void postConstruct() {
		System.out.println("@PostConstruct - Se ha creado el bean");
	}
	
	public void init() {
		System.out.println("init - Se ha creado el bean");
	}
	
	public void metodoDestroy() {
		System.out.println("metodoDestroy - Se va a destruir el bean");
	}

	// Para poder inyectar propiedades, necesitamos metodos get y set
	public int getNumeroEmpleado() {
		return numeroEmpleado;
	}

	public void setNumeroEmpleado(int numeroEmpleado) {
		this.numeroEmpleado = numeroEmpleado;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getApellido() {
		return apellido;
	}

	public void setApellido(String apellido) {
		this.apellido = apellido;
	}

	public boolean isJefe() {
		return jefe;
	}

	public void setJefe(boolean jefe) {
		this.jefe = jefe;
	}

	public double getSueldo() {
		return sueldo;
	}

	public void setSueldo(double sueldo) {
		this.sueldo = sueldo;
	}

	@Override
	public String toString() {
		return "Empleado [numeroEmpleado=" + numeroEmpleado + ", nombre=" + nombre + ", apellido=" + apellido
				+ ", jefe=" + jefe + ", sueldo=" + sueldo + "]";
	}

	
}
