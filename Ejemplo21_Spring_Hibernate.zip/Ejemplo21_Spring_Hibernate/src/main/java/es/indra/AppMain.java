package es.indra;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import es.indra.models.Producto;

public class AppMain {

	public static void main(String[] args) {
		// Levantar el contexto de Spring
		// Leer applicationContext.xml y por cada bean declaro genere
		// la instancia y la guarda en el contenedor
		ApplicationContext ctxApp = new ClassPathXmlApplicationContext("applicationContext.xml");
		
		// Necesito el bean session
		// En este momento se abre la conexion a la BBDD
		Session session = ctxApp.getBean("session", Session.class);
		
		// Obtener una transaccion
		Transaction tx = session.getTransaction();
		
		// Crear las instancias de producto a insertar
		Producto p1 = new Producto(1L, "Pantalla", 129.95);
		Producto p2 = new Producto(2L, "Teclado", 49.50);
		Producto p3 = new Producto(3L, "Raton", 22.75);
		
		try {
			tx.begin();
			
			session.save(p1);
			session.save(p2);
			session.save(p3);
			
			tx.commit();		
		} catch (Exception e) {
			tx.rollback();
			e.printStackTrace();
		} finally {
			// Cerrar la conexion
			session.close();
		}
		
	}

}
