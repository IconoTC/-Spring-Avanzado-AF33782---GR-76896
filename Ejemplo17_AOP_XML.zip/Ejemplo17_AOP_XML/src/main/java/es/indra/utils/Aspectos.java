package es.indra.utils;

import org.aspectj.lang.ProceedingJoinPoint;

public class Aspectos {
	
	public void facturar() {
		System.out.println("Facturando");
	}
	
	public void pasarControl() {
		System.out.println("Pasando el control");
	}
	
	public void embarcar() {
		System.out.println("Embarcando");
	}
	
	public void despegar() {
		System.out.println("Despegando");
	}
	
	public void aterrizar() {
		System.out.println("Aterrizando");
	}
	
	public void recogerEquipaje() {
		System.out.println("Recogiendo el equipaje");
	}
	
	public void emergencia(Exception ex) {
		System.out.println("Tenemos un problema");
		System.out.println(ex.getMessage());
	}
	
	public void medirTiempo(ProceedingJoinPoint pjp) {
		// antes
		long inicio = System.currentTimeMillis();
		System.out.println("Tomando el tiempo de inicio");
		
		try {
			pjp.proceed();  // Llama al metodo viajar
		} catch (Throwable e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		// despues
		long fin = System.currentTimeMillis();
		System.out.println("Tomando el tiempo final");
		System.out.println("Duracion: " + (fin - inicio) + " mseg.");
	}

}
