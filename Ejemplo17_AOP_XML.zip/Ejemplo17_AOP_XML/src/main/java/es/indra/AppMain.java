package es.indra;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import es.indra.business.Vacaciones;

public class AppMain {

	public static void main(String[] args) {
		// Levantar el contexto de Spring
		// Leer applicationContext.xml y por cada bean declaro genere
		// la instancia y la guarda en el contenedor
		ApplicationContext contenedor = new ClassPathXmlApplicationContext("applicationContext.xml");
		
		Vacaciones vacaciones = contenedor.getBean("vacaciones", Vacaciones.class);
		vacaciones.viajar();
		
	}

}
