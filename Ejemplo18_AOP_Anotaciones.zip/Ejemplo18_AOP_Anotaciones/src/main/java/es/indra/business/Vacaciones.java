package es.indra.business;

import org.springframework.stereotype.Service;

@Service
public class Vacaciones {
	
	public void viajar() {
		System.out.println("Nos vamos de vacaciones");
		throw new RuntimeException("Problemas a bordo");
	}

}
