package es.indra;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import es.indra.config.JavaConfig;
import es.indra.models.Producto;

public class AppMain {

	public static void main(String[] args) {
		
		ApplicationContext ctxApp = new AnnotationConfigApplicationContext(JavaConfig.class);
		
		
		EntityManagerFactory emf = (EntityManagerFactory) ctxApp.getBean("emf");
		
		// En este momento se abre la conexion a la BBDD
		EntityManager em = emf.createEntityManager();
		
		
		// Obtener una transaccion
		EntityTransaction tx = em.getTransaction();
		
		// Crear las instancias de producto a insertar
		Producto p1 = new Producto("Pantalla", 129.95);
		Producto p2 = new Producto("Teclado", 49.50);
		Producto p3 = new Producto("Raton", 22.75);
		
		try {
			tx.begin();
			
			em.persist(p1);
			em.persist(p2);
			em.persist(p3);
			
			tx.commit();		
		} catch (Exception e) {
			tx.rollback();
			e.printStackTrace();
		} finally {
			// Cerrar la conexion
			em.close();
		}
		
	}

}
