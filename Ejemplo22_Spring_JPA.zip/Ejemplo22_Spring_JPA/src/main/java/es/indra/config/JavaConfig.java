package es.indra.config;

import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class JavaConfig {
	
	@Bean
	public EntityManagerFactory emf() {
		return Persistence.createEntityManagerFactory("PU");
	}

}
