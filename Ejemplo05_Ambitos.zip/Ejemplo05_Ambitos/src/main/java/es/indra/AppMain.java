package es.indra;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import es.indra.models.Empleado;

public class AppMain {

	public static void main(String[] args) {
		// Levantar el contexto de Spring
		// Leer applicationContext.xml y por cada bean declarado genera
		// la instancia y la guarda en el contenedor
		ApplicationContext contenedor = new ClassPathXmlApplicationContext("applicationContext.xml");
		
		Empleado empl1Singleton = (Empleado) contenedor.getBean("empleado1");
		Empleado empl2Singleton = (Empleado) contenedor.getBean("empleado1");
		System.out.println("Es el mismo bean? " + (empl1Singleton == empl2Singleton));
		
		Empleado empl1Prototype = (Empleado) contenedor.getBean("empleado2");
		Empleado empl2Prototype = (Empleado) contenedor.getBean("empleado2");
		System.out.println("Es el mismo bean? " + (empl1Prototype == empl2Prototype));

	}

}
