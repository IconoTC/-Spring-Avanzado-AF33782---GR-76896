package es.indra.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import es.indra.models.Producto;
import es.indra.persistence.ProductosDao;

@Controller
@RequestMapping("/")
public class TodosController {
	
	@Autowired
	private ProductosDao dao;
	
	
	@RequestMapping(method = RequestMethod.GET, value="todos")
	public String inicio(Model model) {
		
		List<Producto> lista = dao.findAll();
		
		//Guardar la lista como atributo para que desde la pagina jsp se tenga acceso a ella
		model.addAttribute("lista", lista);
		
		return "mostrarTodos";
	}

}
