package es.indra.business;

import es.indra.models.Coche;

public interface ITaller {
	
	void reparar(Coche coche);

}
