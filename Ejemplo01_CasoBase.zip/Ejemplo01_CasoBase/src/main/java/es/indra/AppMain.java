package es.indra;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import es.indra.business.Aseguradora;
import es.indra.models.Coche;

public class AppMain {

	public static void main(String[] args) {
		// Levantar el contexto de Spring
		// Leer applicationContext.xml y por cada bean declaro genere
		// la instancia y la guarda en el contenedor
		ApplicationContext contenedor = new ClassPathXmlApplicationContext("applicationContext.xml");
		
		// Recuperar el bean coche del contenedor
		Coche coche = (Coche) contenedor.getBean("coche");
		
		// Recuperar el bean aseguradora del contenedor
		Aseguradora aseguradora = contenedor.getBean("aseguradora", Aseguradora.class);
		
		aseguradora.arreglarCoche(coche);

	}

}
