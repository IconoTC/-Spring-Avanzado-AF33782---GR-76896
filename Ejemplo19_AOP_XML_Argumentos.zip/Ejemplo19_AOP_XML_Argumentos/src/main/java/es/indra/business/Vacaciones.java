package es.indra.business;

public class Vacaciones {
	
	public void viajar(String numVuelo) {
		System.out.println("Nos vamos de vacaciones en el vuelo " + numVuelo);
		throw new RuntimeException("Problemas a bordo");
	}

}
