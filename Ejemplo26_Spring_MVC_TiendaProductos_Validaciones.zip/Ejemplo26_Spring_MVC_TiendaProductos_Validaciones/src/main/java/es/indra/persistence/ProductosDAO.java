package es.indra.persistence;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import es.indra.models.Producto;

@Repository
public interface ProductosDAO extends JpaRepository<Producto, Long>{
	
	// Podemos crear nuestros propios metodos personalizados utilizando los keywords
	// https://docs.spring.io/spring-data/jpa/reference/repositories/query-keywords-reference.html
	
	// Buscar un producto por su descripcion
	public List<Producto> findByDescripcion(String descripcion);
	
	// Todos los productos ordenados por el precio
	public List<Producto> OrderByPrecio();
	
	// Todos los productos entre un rango de precios
	public List<Producto> findByPrecioBetween(double min, double max);

}
