package es.indra.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import es.indra.models.Producto;
import es.indra.persistence.ProductosDAO;

@Controller
@RequestMapping("/nuevo")
public class NuevoController {
	
	@Autowired
	private ProductosDAO dao;
	
	//@RequestMapping(method = RequestMethod.GET)
	@GetMapping
	public String mostrarFormulario(Model model) {
		// Enviamos al formulario una instancia de Producto vacia
		// para que segun se introducen los datos
		// se guarden como propiedades del objeto		
		model.addAttribute("prod", new Producto());		
		return "formNuevo";
	}
	
	//@RequestMapping(method = RequestMethod.POST)
	@PostMapping
	public String procesarFormulario(Producto producto, Model model) {
		dao.save(producto);
		
		model.addAttribute("msg", "Producto agregado correctamente a nuestra BBDD");
		return "mostrarMensaje";
		
	}

}


