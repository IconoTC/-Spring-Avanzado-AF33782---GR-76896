package es.indra.controllers;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import es.indra.models.Producto;
import es.indra.persistence.ProductosDAO;

@Controller
@RequestMapping("/nuevo")
public class NuevoController {
	
	@Autowired
	private ProductosDAO dao;
	
	//@RequestMapping(method = RequestMethod.GET)
	@GetMapping
	public String mostrarFormulario(Model model) {
		// Enviamos al formulario una instancia de Producto vacia
		// para que segun se introducen los datos
		// se guarden como propiedades del objeto		
		model.addAttribute("prod", new Producto());		
		return "formNuevo";
	}
	
	//@RequestMapping(method = RequestMethod.POST)
	@PostMapping
	// El BindingResult debe ir a continuacion del producto a validar
	public String procesarFormulario(@Valid @ModelAttribute("prod") Producto producto, 
			BindingResult resultado, Model model) {
		
		if (resultado.hasErrors()) {
			return "formNuevo";
		} else {
			dao.save(producto);		
			model.addAttribute("msg", "Producto agregado correctamente a nuestra BBDD");
			return "mostrarMensaje";
		}
				
	}

}


