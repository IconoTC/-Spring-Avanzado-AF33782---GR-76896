package es.indra.utils;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Service;

@Service
@Aspect
@Order(value = 1)  // Solo se puede utilizar a nivel de clase
public class Aspectos {
	
	// Como no puedo tener mas de un punto de corte en la clase,
	// los declaro sobre cada aspecto
	
	// Otra opcion es mantener el punto de corte sin argumentos y 
	// crear el punto de corte con argumentos sobre el aspecto
	@Pointcut("bean(vacaciones)")
	//@Pointcut("execution (* es.indra.business.Vacaciones.viajar(..))")
	public void viajar() {}
	
	// El argumento debe llamarse igual que el recibido en el metodo
	@Before("execution (* es.indra.business.Vacaciones.viajar(..)) && args(nVuelo)")
	public void a_facturar(String nVuelo) {
		System.out.println("Facturando " + nVuelo);
	}
	
	@Before("viajar()")
	public void b_pasarControl() {
		System.out.println("Pasando el control");
	}
	
	@Before("execution (* es.indra.business.Vacaciones.viajar(..)) && args(numeroVuelo))")
	public void c_embarcar(String numeroVuelo) {
		System.out.println("Embarcando " + numeroVuelo);
	}
	
	@Before("viajar()")
	public void d_despegar() {
		System.out.println("Despegando");
	}
	
	@After("viajar()")
	public void aterrizar() {
		System.out.println("Aterrizando");
	}
	
	@AfterReturning("viajar()")
	public void recogerEquipaje() {
		System.out.println("Recogiendo el equipaje");
	}
	
	@AfterThrowing(pointcut = "viajar()", throwing = "ex")
	public void emergencia(Exception ex) {
		System.out.println("Tenemos un problema");
		System.out.println(ex.getMessage());
	}
	
	@Around("viajar()")
	public void medirTiempo(ProceedingJoinPoint pjp) {
		// antes
		long inicio = System.currentTimeMillis();
		System.out.println("Tomando el tiempo de inicio");
		
		try {
			pjp.proceed();  // Llama al metodo viajar
		} catch (Throwable e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		// despues
		long fin = System.currentTimeMillis();
		System.out.println("Tomando el tiempo final");
		System.out.println("Duracion: " + (fin - inicio) + " mseg.");
	}

}
