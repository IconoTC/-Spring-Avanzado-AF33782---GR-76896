package es.indra.business;

import es.indra.models.EmailDetalle;

public interface EmailService {
	
	void enviarEmail(EmailDetalle email);

}
