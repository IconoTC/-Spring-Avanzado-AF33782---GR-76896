package es.indra.business;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

import es.indra.models.EmailDetalle;

@Service
public class EmailServiceImpl implements EmailService{
	
	@Autowired
	private JavaMailSender javaMailSender; 

	@Override
	public void enviarEmail(EmailDetalle email) {
		SimpleMailMessage mensajeMailMessage = new SimpleMailMessage();
		mensajeMailMessage.setFrom("tuCorreo");
		mensajeMailMessage.setTo(email.getDestinatario());
		mensajeMailMessage.setSubject(email.getAsunto());
		mensajeMailMessage.setText(email.getMensaje());
		javaMailSender.send(mensajeMailMessage);
	}

}
