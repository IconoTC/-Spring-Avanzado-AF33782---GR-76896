package es.indra;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import es.indra.business.EmailService;
import es.indra.models.EmailDetalle;

@SpringBootApplication
public class Ejemplo35SpringMailApplication implements CommandLineRunner{
	
	@Autowired
	private EmailService emailService;

	public static void main(String[] args) {
		SpringApplication.run(Ejemplo35SpringMailApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		EmailDetalle emailDetalle = new EmailDetalle("pepito@gmail.com", "Cena", "Quedamos hoy para cenar?");
		emailService.enviarEmail(emailDetalle);
		
	}

}
