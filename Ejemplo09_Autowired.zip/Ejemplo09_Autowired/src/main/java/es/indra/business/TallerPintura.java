package es.indra.business;

import es.indra.models.Coche;

public class TallerPintura implements ITaller{

	public void reparar(Coche coche) {
		System.out.println("En el taller de pintura, se repara el coche " + coche);
		
	}

}
