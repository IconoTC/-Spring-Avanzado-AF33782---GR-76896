package es.indra.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.remoting.rmi.RmiProxyFactoryBean;

import es.indra.business.PolizaBS;
import es.indra.business.PolizaService;

@Configuration
@ComponentScan(basePackages = "es.indra")
public class JavaConfig {
	
	// Crear un bean para obtener el proxy (Stub) del servicio
	@Bean
	public RmiProxyFactoryBean rmiProxyFactoryBean(){
		RmiProxyFactoryBean rmiProxyFactoryBean = new RmiProxyFactoryBean();
		rmiProxyFactoryBean.setServiceUrl("rmi://127.0.0.1:9876/servicioPolizas");
		rmiProxyFactoryBean.setServiceInterface(PolizaService.class);
		return rmiProxyFactoryBean;
	}
	
}
