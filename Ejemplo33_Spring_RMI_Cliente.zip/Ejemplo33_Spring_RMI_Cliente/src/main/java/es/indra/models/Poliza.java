package es.indra.models;

import java.io.Serializable;

public class Poliza implements Serializable{
	
	private String dato;

	public Poliza(String dato) {
		super();
		this.dato = dato;
	}

	public String getDato() {
		return dato;
	}

	public void setDato(String dato) {
		this.dato = dato;
	}

	@Override
	public String toString() {
		return "Poliza [dato=" + dato + "]";
	}
	

}
