package es.indra.business;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import es.indra.models.Poliza;

@Service
public class PolizaBS {
	
	@Autowired
	private PolizaService service;
	
	public List<Poliza> consultarTodas(){
		return service.obtenerPolizas();
	}

	public PolizaService getService() {
		return service;
	}

	public void setService(PolizaService service) {
		this.service = service;
	}
	
	

}
