package es.indra;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import es.indra.config.JavaConfig;

public class AppMain {

	public static void main(String[] args) {
		// Levantamos el contexto de Spring
		ApplicationContext appCtx = new AnnotationConfigApplicationContext(JavaConfig.class);
		
		System.out.println("******** Servicio arrancado ********");

	}

}
