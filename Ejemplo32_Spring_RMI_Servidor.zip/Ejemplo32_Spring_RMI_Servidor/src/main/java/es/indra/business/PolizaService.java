package es.indra.business;

import java.util.List;

import es.indra.models.Poliza;

public interface PolizaService {
	
	public List<Poliza> obtenerPolizas();
	
	public void insertarPoliza();

}
