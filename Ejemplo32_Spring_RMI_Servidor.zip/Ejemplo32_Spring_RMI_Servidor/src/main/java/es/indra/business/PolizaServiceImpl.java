package es.indra.business;

import java.util.Arrays;
import java.util.List;

import org.springframework.stereotype.Service;

import es.indra.models.Poliza;

public class PolizaServiceImpl implements PolizaService {

	private List<Poliza> lista = Arrays.asList(new Poliza("Seguro de casa"), new Poliza("Seguro de vida"),
			new Poliza("Seguro del coche"), new Poliza("Seguro de moto"));

	@Override
	public List<Poliza> obtenerPolizas() {
		System.out.println("<<<<<< Obteniendo polizas >>>>>> ");
		return lista;
	}

	@Override
	public void insertarPoliza() {
		System.out.println("<<<<<< Insertando nueva poliza >>>>>> ");
	}

}
