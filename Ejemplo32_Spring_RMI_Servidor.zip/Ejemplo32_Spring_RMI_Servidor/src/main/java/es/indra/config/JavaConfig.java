package es.indra.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.remoting.rmi.RmiServiceExporter;

import es.indra.business.PolizaService;
import es.indra.business.PolizaServiceImpl;

@Configuration
@ComponentScan(basePackages = "es.indra")
public class JavaConfig {
	
	@Bean
	public PolizaService polizaService() {
		return new PolizaServiceImpl();
	}
	
	@Bean
	public RmiServiceExporter rmiServiceExporter() {
		RmiServiceExporter rmiService = new RmiServiceExporter();
		rmiService.setService(polizaService());
		rmiService.setServiceName("servicioPolizas");
		rmiService.setServiceInterface(PolizaService.class);
		rmiService.setRegistryPort(9876);
		return rmiService;
	}

}
