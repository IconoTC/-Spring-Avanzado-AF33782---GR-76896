package es.indra.business;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

@Service
public class TareaProgramada {
	
	@Scheduled(fixedRate = 6000)  // 6000 milisegundos
	public void mostrarHora() {		
		SimpleDateFormat dateFormat = new SimpleDateFormat("HH:mm:ss");
		System.out.println("Hora actual: " + dateFormat.format(new Date() ));
	}

}
