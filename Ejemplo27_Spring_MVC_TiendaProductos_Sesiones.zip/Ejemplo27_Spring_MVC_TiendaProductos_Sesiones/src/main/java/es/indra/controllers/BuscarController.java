package es.indra.controllers;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import es.indra.models.Producto;
import es.indra.persistence.ProductosDAO;

@Controller
@RequestMapping("/buscar")
public class BuscarController {
	
	@Autowired
	private ProductosDAO dao;
	
	//@RequestMapping(method = RequestMethod.GET)
	@GetMapping
	public String mostrarFormulario(Model model) {
		// Enviamos al formulario una instancia de Producto vacia
		// para que segun se introducen los datos
		// se guarden como propiedades del objeto		
		model.addAttribute("prod", new Producto());		
		return "formBuscar";
	}
	
	//@RequestMapping(method = RequestMethod.POST)
	@PostMapping
	public String procesarFormulario(Producto producto, Model model) {
		Optional<Producto> opProducto = dao.findById(producto.getId());
		
		if (opProducto.isPresent()) {
			model.addAttribute("encontrado", opProducto.get());
			return "mostrarProducto";
		} else {
			model.addAttribute("msg", "Lo sentimos, ese producto no existe en nuestro catalogo");
			return "mostrarMensaje";
		}
	}

}


