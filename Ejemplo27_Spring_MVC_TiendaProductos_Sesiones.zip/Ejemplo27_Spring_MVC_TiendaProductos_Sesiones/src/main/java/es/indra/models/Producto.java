package es.indra.models;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.DecimalMin;
import javax.validation.constraints.Digits;
import javax.validation.constraints.Size;

@Entity
@Table(name = "PRODUCTOS_JPA")
public class Producto implements Serializable {

	@Id
	@Column(name = "ID_PRODUCTO")
	@GeneratedValue(strategy = GenerationType.IDENTITY) // Autoincremental
	//@Digits(integer = 3, fraction = 0, message = "Debe tener como maximo 3 digitos enteros")
	private Long id;

	@Column(name = "DESCRIPCION")
	@Size(min = 3, max = 20, message = "Longitud entre 3 y 20 caracteres")
	private String descripcion;

	@Column(name = "PRECIO")
	@DecimalMin(value = "1", message = "Precio minimo 1€")
	private double precio;

	public Producto() {
		// TODO Auto-generated constructor stub
	}

	public Producto(String descripcion, double precio) {
		super();
		this.descripcion = descripcion;
		this.precio = precio;
	}

	public Producto(Long id, String descripcion, double precio) {
		super();
		this.id = id;
		this.descripcion = descripcion;
		this.precio = precio;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public double getPrecio() {
		return precio;
	}

	public void setPrecio(double precio) {
		this.precio = precio;
	}

	@Override
	public String toString() {
		return "Producto [id=" + id + ", descripcion=" + descripcion + ", precio=" + precio + "]";
	}

}
