package es.indra;

import java.util.List;

import org.springframework.batch.core.BatchStatus;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.listener.JobExecutionListenerSupport;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

@Component
public class JobTerminadoListener  extends JobExecutionListenerSupport{
	
	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	private long inicio;

	@Override
	public void afterJob(JobExecution jobExecution) {
		if (jobExecution.getStatus() == BatchStatus.COMPLETED) {
			List<Producto> lista = jdbcTemplate.query("select * from productos", 
					(resultSet,row) -> new Producto(
							resultSet.getInt("id"),
							resultSet.getString("descripcion"),
							resultSet.getDouble("precio")
							));
			for (Producto producto : lista) {
				System.out.println(producto);
			}
		}
		
		// Tomar el tiempo final
		long fin = System.currentTimeMillis();
		System.out.println("Finalizando el proceso Job -----------");
		System.out.println("Tiempo de ejecucion: " + (fin-inicio) + " mseg.");
	}

	@Override
	public void beforeJob(JobExecution jobExecution) {
		// Tomar el tiempo de inicio
		inicio = System.currentTimeMillis();
		System.out.println("Iniciando el proceso Job -----------");
	}
	
	

}
