package es.indra.config;

import java.util.Collections;
import java.util.Properties;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.handler.SimpleUrlHandlerMapping;
import org.springframework.webflow.config.AbstractFlowConfiguration;
import org.springframework.webflow.definition.registry.FlowDefinitionRegistry;
import org.springframework.webflow.engine.builder.support.FlowBuilderServices;
import org.springframework.webflow.executor.FlowExecutor;
import org.springframework.webflow.mvc.builder.MvcViewFactoryCreator;
import org.springframework.webflow.mvc.servlet.FlowController;
import org.springframework.webflow.mvc.servlet.FlowHandlerAdapter;
import org.springframework.webflow.mvc.servlet.FlowHandlerMapping;

@Configuration
@ComponentScan("es.indra")
public class WebFlowConfig extends AbstractFlowConfiguration {
	
	@Autowired
    private JavaConfig javaConfig;
	
	@Bean
    public FlowDefinitionRegistry flowRegistry() {
        return getFlowDefinitionRegistryBuilder(flowBuilderServices())
          .addFlowLocation("/WEB-INF/flujos/principal-flow.xml", "inicio")
          .build();
    }
	
//	@Bean
//	public FlowDefinitionRegistry flowRegistry(){
//		return getFlowDefinitionRegistryBuilder()
//				.setBasePath("/WEB-INF/flujos")
//				.addFlowLocationPattern("/*-flow.xml")
//				.setFlowBuilderServices(flowBuilderServices())
//				.build();
//	}

    @Bean
    public FlowExecutor flowExecutor() {
        return getFlowExecutorBuilder(flowRegistry()).build();
    }

    @Bean
    public FlowBuilderServices flowBuilderServices() {
        return getFlowBuilderServicesBuilder()
          .setViewFactoryCreator(mvcViewFactoryCreator())
          .setDevelopmentMode(true).build();
    }

    @Bean
    public MvcViewFactoryCreator mvcViewFactoryCreator() {
        MvcViewFactoryCreator factoryCreator = new MvcViewFactoryCreator();
        factoryCreator.setViewResolvers(
          Collections.singletonList(this.javaConfig.beanNameViewResolver()));
        factoryCreator.setUseSpringBeanBinding(true);
        return factoryCreator;
    }
    
    @Bean
	public FlowHandlerMapping flowHandlerMapping() {
		FlowHandlerMapping handlerMapping = new FlowHandlerMapping();
		handlerMapping.setFlowRegistry(flowRegistry());
		return handlerMapping;
	}
	
	@Bean
	public FlowHandlerAdapter flowHandlerAdapter() {
		FlowHandlerAdapter handlerAdapter = new FlowHandlerAdapter();
		handlerAdapter.setFlowExecutor(flowExecutor());
		return handlerAdapter;
	}

	@Bean
	public FlowController  flowController(){
		FlowController flowController = new FlowController();
		flowController.setFlowExecutor(flowExecutor());
		return flowController;
	}
	
	@Bean
	public SimpleUrlHandlerMapping simpleUrlHandlerMapping() {
		SimpleUrlHandlerMapping urlHandlerMapping = new SimpleUrlHandlerMapping();
		Properties properties = new Properties();
		properties.setProperty("inicio", "flowController");
		urlHandlerMapping.setMappings(properties);
		urlHandlerMapping.setAlwaysUseFullPath(true);
		return urlHandlerMapping;
	}
	
//	@Autowired
//	private FlowBuilderServices flowBuilderServices;
//	
//	@Bean
//	public FlowDefinitionRegistry flowRegistry(){
//		return getFlowDefinitionRegistryBuilder()
//				.setBasePath("/WEB-INF/flujos")
//				.addFlowLocationPattern("/*-flow.xml")
//				.setFlowBuilderServices(flowBuilderServices)
//				.build();
//	}
//	
//	@Bean
//	public FlowExecutor flowExecutor() {
//		return getFlowExecutorBuilder(flowRegistry()).build();
//	}
//	
//	@Bean
//	public FlowHandlerMapping flowHandlerMapping() {
//		FlowHandlerMapping handlerMapping = new FlowHandlerMapping();
//		handlerMapping.setFlowRegistry(flowRegistry());
//		return handlerMapping;
//	}
//	
//	@Bean
//	public FlowHandlerAdapter flowHandlerAdapter() {
//		FlowHandlerAdapter handlerAdapter = new FlowHandlerAdapter();
//		handlerAdapter.setFlowExecutor(flowExecutor());
//		return handlerAdapter;
//	}

}
