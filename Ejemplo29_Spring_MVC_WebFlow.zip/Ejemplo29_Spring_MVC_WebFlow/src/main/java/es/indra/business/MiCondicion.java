package es.indra.business;

import org.springframework.stereotype.Service;

@Service(value = "condicion")
public class MiCondicion {
	
	public boolean comprobar(int numero) {
		return numero % 2 == 0;
	}

}
