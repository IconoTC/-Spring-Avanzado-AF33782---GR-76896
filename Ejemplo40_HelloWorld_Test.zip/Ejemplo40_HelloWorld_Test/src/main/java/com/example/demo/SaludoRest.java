package com.example.demo;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class SaludoRest {
	
	// http://localhost:8080/hola
	@RequestMapping("/hola")
	public String hola() {
		return "Bienvenidos al curso";
	}
	
	// http://localhost:8080/adios?usuario="Anabel"
	//@RequestMapping("/adios")
	@RequestMapping(method=RequestMethod.GET, value="/adios")
	public String adios(@RequestParam(value="usuario", defaultValue="Admin") String user) {
		return "Nos vamos a desayunar " + user;
	}

}
